<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajax Form Send Mail</title>

    

    <link href ="index.css" rel="stylesheet">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.2.1.min.js" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.1.2/sweetalert2.all.min.js"></script>
<link rel= "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.1.2/sweetalert2.min.css"></script>

</head>
<div id="mainbody">
<body>


<div id="overlay"></div>

<div class="container">
<h1 class="title">Personal Information</h1>
<form method="post" action="send.php" id="contactform">

<div class="form-group">
<section >
<label >Preferred year of commencement of studies </label>
<input  type="text" name="ff_nm_Year[]" class="form-control" required>
</section>
</div>

<div class="form-group">
<section >
<label> Intake</label>
<span >
<input   type="radio" name="ff_nm_Intake[]" value="January" class="form-control" required><label class="form-control" >January</label>
<input   type="radio" name="ff_nm_Intake[]" value="May" class="form-control" required><label class="form-control">May</label>
<input   type="radio" name="ff_nm_Intake[]" value="September" class="form-control" required><label class="form-control">September</label>
</span>
</section>
</div>

<div class="form-group">
<section >
<label >Campus of study </label>
<span >
<input  type="radio" name="ff_nm_Campus[]" value="Limuru" class="form-control" required><label >Main campus (Limuru)</label>
<input   type="radio" name="ff_nm_Campus[]" value="Nairobi" class="form-control" required><label >Nairobi</label>
<input   type="radio" name="ff_nm_Campus[]" value="Nakuru" class="form-control" required><label >Nakuru</label>
<input  type="radio" name="ff_nm_Campus[]" value="Machakos" class="form-control" required><label >Machakos</label>
</span>
</section>
</div>

<div class="form-group">
<section >
<label >Preferred mode of study</label>
<span >
<input   type="radio" name="ff_nm_Studymode[]" value="Regular" class="form-control" required><label >Regular/Day</label><br/>
<input  type="radio" name="ff_nm_Studymode[]" value="Evening" class="form-control" required><label >Evening</label><br/>
<input   type="radio" name="ff_nm_Studymode[]" value="Distancelearning" class="form-control" required><label >Distance learning</label><br/>
<input   type="radio" name="ff_nm_Studymode[]" value="Schoolbased" class="form-control" required><label >School Based (Education programmes)</label><br/>
<input  type="radio" name="ff_nm_Studymode[]" value="Modular" >Modular</label>
</span>
</section>
</div>

<div class="form-group">
<legend><span ><span ><span >Programmes</span></span></span></legend>
<section >
<label >PhD Programmes</label>
<select data-chosen="no-chzn" name="ff_nm_PhD[]" >
<option value="">- Select PhD Program -</option>
<option value="Doctor of Philosophy in Business Administration and Management">Doctor of Philosophy in Business Administration and Management</option>
<option value="Doctor of Philosophy in Development Studies">Doctor of Philosophy in Development Studies</option>
<option value="Doctor of Philosophy in Theology">Doctor of Philosophy in Theology</option>
</select>
</section>
</div>

<div class="form-group">
<section >
<label >Masters' Programmes</label>
<select data-chosen="no-chzn"  name="ff_nm_Masters[]" >
<option value="">- Select Masters Program -</option>
<option value="Masters of Arts in Communication">Masters of Arts in Communication</option>
<option value="Master of Arts in Community Care and HIV/AIDS">Master of Arts in Community Care and HIV/AIDS</option>
<option value="Masters of Arts in Counseling Psychology">Masters of Arts in Counseling Psychology</option>
<option value="Masters in Islam and Christian-Muslim Relations (ICMR)">Masters in Islam and Christian-Muslim Relations (ICMR)</option>
<option value="Masters of Arts in Sociology">Masters of Arts in Sociology</option>
<option value="Masters of Arts in Transformational Leadership">Masters of Arts in Transformational Leadership</option>
<option value="Masters of Business Administration (MBA)">Masters of Business Administration (MBA)</option>
<option value="Masters of Development Studies (MDS)">Masters of Development Studies (MDS)</option>
<option value="Master of Education (Early Childhood Studies)">Master of Education (Early Childhood Studies)</option>
<option value="Masters of Procurement and Logistics Management">Masters of Procurement and Logistics Management</option>
<option value="Masters of Public Administration and Policy">Masters of Public Administration and Policy</option>
<option value="Masters of Theology">Masters in Theology</option>
</select>
</section>
</div><br>




<section >
<label >Undergraduate Programmes</label>
<select data-chosen="no-chzn" name="ff_nm_Undergraduate[]" >
<option value="">- Select Undergraduate Program -</option>
<option value="Bachelor of Arts in Communication">Bachelor of Arts in Communication</option>
<option value="Bachelor of Arts in Community Development">Bachelor of Arts in Community Development</option>
<option value="Bachelor of Arts in Counseling Psychology">Bachelor of Arts in Counseling Psychology</option>
<option value="Bachelor of Arts in Criminal Justice and Security Studies">Bachelor of Arts in Criminal Justice and Security Studies</option>
<option value="Bachelor of Arts in Leadership and Management">Bachelor of Arts in Leadership and Management</option>
<option value="Bachelor of Arts in Peace &amp; Conflict Studies">Bachelor of Arts in Peace &amp; Conflict Studies</option>
<option value="Bachelor of Arts in Social Work">Bachelor of Arts in Social Work</option>
<option value="Bachelor of Business Administration &amp; Management">Bachelor of Business Administration &amp; Management</option>
<option value="Bachelor of Business and Information Technology">Bachelor of Business and Information Technology</option>
<option value="Bachelor of Commerce">Bachelor of Commerce</option>
<option value="Bachelor of Science in Computer Science">Bachelor of Science in Computer Science</option>
<option value="Bachelor of Divinity">Bachelor of Divinity</option>
<option value="Bachelor of Education (Arts)">Bachelor of Education (Arts)</option>
<option value="Bachelor of Education in Early Childhood Development and Education">Bachelor of Education in Early Childhood Development and Education</option>
<option value="Bachelor of Education (Special Needs)">Bachelor of Education (Special Needs)</option>
<option value="Bachelor of Science in Computing and Information Systems">Bachelor of Science in Computing and Information Systems</option>
<option value="Bachelor of Science in Health Records Management and Informatics">Bachelor of Science in Health Records Management and Informatics</option>
<option value="Bachelor of Science in Health Systems Management and Economics">Bachelor of Science in Health Systems Management and Economics</option>
<option value="Bachelor of Science in Nursing (Regular)">Bachelor of Science in Nursing (Regular)</option>
</select>
</section>
</form>
</div>
</body>
<div>
