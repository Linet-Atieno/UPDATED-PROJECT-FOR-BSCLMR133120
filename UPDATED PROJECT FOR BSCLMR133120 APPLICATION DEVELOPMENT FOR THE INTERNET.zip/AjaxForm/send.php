<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$FirstName = strip_tags($_POST['FirstName']);
$LastName = strip_tags($_POST['LastName']);
$YourEmail = strip_tags($_POST['YourEmail']);
$YourInquiry = strip_tags($_POST['YourInquiry']);
$DOB = strip_tags($_POST['DOB']);
$citizenship = strip_tags($_POST['citizenship ']);
$country = strip_tags($_POST['country ']);
$ID = strip_tags($_POST['ID']);
$gender = strip_tags($_POST['gender']);
$formal = strip_tags($_POST['formal']);
$ff_nm_EducationLevel[] = strip_tags($_POST['ff_nm_EducationLevel[]']);
$Specification  = strip_tags($_POST['Specification']);
$ff_nm_Passportphoto[] = strip_tags($_POST['ff_nm_Passportphoto[]']);
$language  = strip_tags($_POST['language']);
$disability  = strip_tags($_POST['disability']);
$nature  = strip_tags($_POST['nature ']);
$ff_nm_Religious[] = strip_tags($_POST['ff_nm_Religious[]  ']);
$affiliation  = strip_tags($_POST['affiliation ']);
$ff_nm_Postaladdress[]  = strip_tags($_POST['ff_nm_Postaladdress[]']);
$ff_nm_Code[]  = strip_tags($_POST['ff_nm_Code[] ']);
$ff_nm_Town[]   = strip_tags($_POST[' ff_nm_Town[] ']);
$ff_nm_Countryofresidence[] = strip_tags($_POST[' ff_nm_Countryofresidence[]']);
$ff_nm_Telephone[]  = strip_tags($_POST[' ff_nm_Telephone[]']);
$ff_nm_Mobileno[] = strip_tags($_POST['ff_nm_Mobileno[] ']);




//validation
if(empty($FirstName)){
    header('location:index.php? error=name');
    exit();
}

if(empty($LastName)){
    header('location:index.php? error=name');
    exit();
}

if(empty($email)){
    header('location:index.php? error=email');
    exit();
}

if(empty($inquiry)){
    header('location:index.php error=inquiry');
    exit();
}

if(empty($DOB)){
    header('location:index.php error=DOB');
    exit();
}
if(empty($citizenship)){
    header('location:index.php error=citizenship');
    exit();
}
if(empty($country)){
    header('location:index.php error=country');
    exit();
}
if(empty($ID)){
    header('location:index.php error=ID');
    exit();
}
if(empty($gender)){
    header('location:index.php error=Gender');
    exit();
}
if(empty($formal)){
    header('location:index.php error=Formal');
    exit();
}
if(empty($ff_nm_EducationLevel)){
    header('location:index.php error=education_level');
    exit();
}
if(empty($specification)){
    header('location:index.php error=education_level');
    exit();
}
if(empty($ff_nm_Passportphoto)){
    header('location:index.php error=education_level');
    exit();
}
if(empty($level)){
    header('location:index.php error=Formal');
    exit();
}
if(empty($language)){
    header('location:index.php error=language');
    exit();
}
if(empty($disability)){
    header('location:index.php error=dissability');
    exit();
}
if(empty($ff_nm_Religious)){
    header('location:index.php error=religion');
    exit();
}
if(empty($ff_nm_Postaladdress)){
    header('location:index.php error=postaladdress');
    exit();
}
if(empty($ff_nm_Code)){
    header('location:index.php error=code');
    exit();
}
if(empty($ff_nm_Town)){
    header('location:index.php error=town');
    exit();
}
if(empty($ff_nm_Countryofresidence)){
    header('location:index.php error=country');
    exit();
}
if(empty($ff_nm_Telephone)){
    header('location:index.php error=telephone');
    exit();
}



//load composer's autoloader
require 'vender/autoload.php';

$mail = new PHPMailer(true);

try {
    //Server settings
    $mail->SMTPDebug = 0;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'linetjatieno@gmail.com';                     //SMTP username
    $mail->Password   = 'kaimosi2018';                               //SMTP password
    $mail->SMTPSecure = 'tls';            //Enable implicit TLS encryption
    $mail->Port       = 587;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom('linetjatieno@gmail.com', 'Linet');
    $mail->addAddress('linet5088@gmail.com');     //Add a recipient

    //Attachments
    $mail->addAttachment('/xampp\htdocs\AjaxForm2\index.php');         //Add attachments
    $mail->addAttachment('/xampp\htdocs\AjaxForm2\send.php','Ajaxo');    //Optional name

    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'Form filled by ' . $FirstName.$LastName;

    $body = "
        Dear Admin you have received an inquiry from $FirstName.$LastName <br/>
        The inquiry details ia as follows:<br/>

        First_Name: $FirstName<br/>
        Last_Name: $LastName <br/>

        Email: <a> $email </a><br/>
        Date of Birth: <a> $DOB </a><br/>
        Citizenship: $citizenship<br/>
        Country: $country<br/>
        ID / Passport Number: $ID<br/>
        Gender: $gender<br/>
        Inquiry: $inquiry<br/>
        Years of Formal Education in English: $formal<br/>
        Highest Level Of Education: $level<br/>
        If others, please specify: $specification</br>
        Passport: $passport</br>
        Any Language Spoken And Written: $language<br/>
        Dissability: $disability<br/>
        Nature Of Dissability:$nature<br/>
        Religion:$ff_nm_Religious<br/>
        Specification Of Religious Affiliation:$affiliation<br/>
        Postal Address:$ff_nm_Postaladdress<br/>
        Code:$ff_nm_Code<br/>
        Town:$ff_nm_Town<br/>
        Country Of Residence: $ff_nm_Countryofresidence<br/>
        Telephone Number:$ff_nm_Telephone<br/>

       
    ";


    

    $mail->Body    = $body ;
    $mail->AltBody = strip_tags($body);

    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}


?>