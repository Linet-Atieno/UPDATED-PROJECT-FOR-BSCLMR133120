<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajax Form Send Mail</title>

    

    <link href ="index.css" rel="stylesheet">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.2.1.min.js" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.1.2/sweetalert2.all.min.js"></script>
<link rel= "stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.1.2/sweetalert2.min.css"></script>

</head>

<body>







<div id="smallbody">
<section class="bfPageIntro">
<h1 style="text-align: center;"><strong><span style="font-size: medium;">APPLICATION FOR ADMISSION</span></strong></h1>
<h1><strong><span style="font-size: medium;">APPLICATION PROCEDURE</span></strong><span style="font-size: 12.16px; line-height: 1.3em;"> </span></h1>
<ol>
<li>Attach photocopies of all academic and professional certificates. If they are not in English send translated and certified<br />copies. Non-English speakers must provide proof of competence in English.</li>
<li>Attach a copy of your recent coloured passport size photographs.</li>
<li>Please note that you are required to pay a non refundable application fee for your application to be processed.
<ul>
<li>Postgraduate Application Fee- KSh.3,000.00</li>
<li>Undergraduate Application Fee- KSh. 1,500.00</li>
<li>Diploma &amp; Certificate Application Fee- KSh. 1,000.00<span style="font-size: 12.16px; line-height: 1.3em;"> </span></li>
<li>You can deposit the application fee in any of our bank accounts and then scan and attach the bank slip here. <a href="/new/bank-account-details" rel="alternate">Click here to view bank account details.</a></li>
</ul>
</li>
</ol>
</section>
</div>


<div id="mainbody">
    <div id="overlay"></div>

    <div class="container">
    <h1 class="title">Personal Information</h1>
    <form method="post" action="send.php" id="contactform">
      
        <div class="form-group">
        <label>First Name </label> <input type="text" name="FirstName" class="form-control" required>
        </div>

        <div class="form-group">
        <label>Last Name </label> <input type="text" name="LastName" class="form-control" required>
        </div>

        <div class="form-group">
        <label>Your Date of birth</label> <input type="date"  name="DOB" class="form-control" required>
        </div>

        <div class="form-group">
        <label>Citizenship </label> <input type="text" name="citizenship" class="form-control" required>
        </div>
 <div class="form-group">
 <label  >Country </label> 
<select data-chosen="no-chzn" class="ff_elem chzn-done" name="country"  class="form-control" required>
<option value="">-Select country-</option>
<option value="Afghanistan">Afghanistan</option>
<option value="Albania">Albania</option>
<option value="Algeria">Algeria</option>
<option value="Andorra">Andorra</option>
<option value="Angola">Angola</option>
<option value="Antigua and Barbuda">Antigua and Barbuda</option>
<option value="Argentina">Argentina</option>
<option value="Armenia">Armenia</option>
<option value="Australia">Australia</option>
<option value="Austria">Austria</option>
<option value="Azerbaijan">Azerbaijan</option>
<option value="Bahamas">Bahamas</option>
<option value="Bahrain">Bahrain</option>
<option value="Bangladesh">Bangladesh</option>
<option value="Barbados">Barbados</option>
<option value="Belarus">Belarus</option>
<option value="Belgium">Belgium</option>
<option value="Belize">Belize</option>
<option value="Benin">Benin</option>
<option value="Bhutan">Bhutan</option>
<option value="Bolivia">Bolivia</option>
<option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
<option value="Botswana">Botswana</option>
<option value="Brazil">Brazil</option>
<option value="Brunei">Brunei</option>
<option value="Bulgaria">Bulgaria</option>
<option value="Burkina Faso">Burkina Faso</option>
<option value="Burundi">Burundi</option>
<option value="Cambodia">Cambodia</option>
<option value="Cameroon">Cameroon</option>
<option value="Canada">Canada</option>
<option value="Cape Verde">Cape Verde</option>
<option value="Central African Republic">Central African Republic</option>
<option value="Chad">Chad</option>
<option value="Chile">Chile</option>
<option value="China">China</option>
<option value="Colombia">Colombia</option>
<option value="Comoros">Comoros</option>
<option value="Congo (Brazzaville)">Congo (Brazzaville)</option>
<option value="Congo">Congo</option>
<option value="Costa Rica">Costa Rica</option>
<option value="Cote d&#039;Ivoire">Cote d&#039;Ivoire</option>
<option value="Croatia">Croatia</option>
<option value="Cuba">Cuba</option>
<option value="Cyprus">Cyprus</option>
<option value="Czech Republic">Czech Republic</option>
<option value="Denmark">Denmark</option>
<option value="Djibouti">Djibouti</option>
<option value="Dominica">Dominica</option>
<option value="Dominican Republic">Dominican Republic</option>
<option value="East Timor (Timor Timur)">East Timor (Timor Timur)</option>
<option value="Ecuador">Ecuador</option>
<option value="Egypt">Egypt</option>
<option value="El Salvador">El Salvador</option>
<option value="Equatorial Guinea">Equatorial Guinea</option>
<option value="Eritrea">Eritrea</option>
<option value="Estonia">Estonia</option>
<option value="Ethiopia">Ethiopia</option>
<option value="Fiji">Fiji</option>
<option value="Finland">Finland</option>
<option value="France">France</option>
<option value="Gabon">Gabon</option>
<option value="Gambia">Gambia</option>
<option value="Georgia">Georgia</option>
<option value="Germany">Germany</option>
<option value="Ghana">Ghana</option>
<option value="Greece">Greece</option>
<option value="Grenada">Grenada</option>
<option value="Guatemala">Guatemala</option>
<option value="Guinea">Guinea</option>
<option value="Guinea-Bissau">Guinea-Bissau</option>
<option value="Guyana">Guyana</option>
<option value="Haiti">Haiti</option>
<option value="Honduras">Honduras</option>
<option value="Hungary">Hungary</option>
<option value="Iceland">Iceland</option>
<option value="India">India</option>
<option value="Indonesia">Indonesia</option>
<option value="Iran">Iran</option>
<option value="Iraq">Iraq</option>
<option value="Ireland">Ireland</option>
<option value="Israel">Israel</option>
<option value="Italy">Italy</option>
<option value="Jamaica">Jamaica</option>
<option value="Japan">Japan</option>
<option value="Jordan">Jordan</option>
<option value="Kazakhstan">Kazakhstan</option>
<option selected="selected" value="Kenya">Kenya</option>
<option value="Kiribati">Kiribati</option>
<option value="Korea, North">Korea, North</option>
<option value="Korea, South">Korea, South</option>
<option value="Kuwait">Kuwait</option>
<option value="Kyrgyzstan">Kyrgyzstan</option>
<option value="Laos">Laos</option>
<option value="Latvia">Latvia</option>
<option value="Lebanon">Lebanon</option>
<option value="Lesotho">Lesotho</option>
<option value="Liberia">Liberia</option>
<option value="Libya">Libya</option>
<option value="Liechtenstein">Liechtenstein</option>
<option value="Lithuania">Lithuania</option>
<option value="Luxembourg">Luxembourg</option>
<option value="Macedonia">Macedonia</option>
<option value="Madagascar">Madagascar</option>
<option value="Malawi">Malawi</option>
<option value="Malaysia">Malaysia</option>
<option value="Maldives">Maldives</option>
<option value="Mali">Mali</option>
<option value="Malta">Malta</option>
<option value="Marshall Islands">Marshall Islands</option>
<option value="Mauritania">Mauritania</option>
<option value="Mauritius">Mauritius</option>
<option value="Mexico">Mexico</option>
<option value="Micronesia">Micronesia</option>
<option value="Moldova">Moldova</option>
<option value="Monaco">Monaco</option>
<option value="Mongolia">Mongolia</option>
<option value="Morocco">Morocco</option>
<option value="Mozambique">Mozambique</option>
<option value="Myanmar">Myanmar</option>
<option value="Namibia">Namibia</option>
<option value="Nauru">Nauru</option>
<option value="Nepa">Nepa</option>
<option value="Netherlands">Netherlands</option>
<option value="New Zealand">New Zealand</option>
<option value="Nicaragua">Nicaragua</option>
<option value="Niger">Niger</option>
<option value="Nigeria">Nigeria</option>
<option value="Norway">Norway</option>
<option value="Oman">Oman</option>
<option value="Pakistan">Pakistan</option>
<option value="Palau">Palau</option>
<option value="Panama">Panama</option>
<option value="Papua New Guinea">Papua New Guinea</option>
<option value="Paraguay">Paraguay</option>
<option value="Peru">Peru</option>
<option value="Philippines">Philippines</option>
<option value="Poland">Poland</option>
<option value="Portugal">Portugal</option>
<option value="Qatar">Qatar</option>
<option value="Romania">Romania</option>
<option value="Russia">Russia</option>
<option value="Rwanda">Rwanda</option>
<option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
<option value="Saint Lucia">Saint Lucia</option>
<option value="Saint Vincent">Saint Vincent</option>
<option value="Samoa">Samoa</option>
<option value="San Marino">San Marino</option>
<option value="Sao Tome and Principe">Sao Tome and Principe</option>
<option value="Saudi Arabia">Saudi Arabia</option>
<option value="Senegal">Senegal</option>
<option value="Serbia and Montenegro">Serbia and Montenegro</option>
<option value="Seychelles">Seychelles</option>
<option value="Sierra Leone">Sierra Leone</option>
<option value="Singapore">Singapore</option>
<option value="Slovakia">Slovakia</option>
<option value="Slovenia">Slovenia</option>
<option value="Solomon Islands">Solomon Islands</option>
<option value="Somalia">Somalia</option>
<option value="South Africa">South Africa</option>
<option value="Spain">Spain</option>
<option value="Sri Lanka">Sri Lanka</option>
<option value="Sudan">Sudan</option>
<option value="Suriname">Suriname</option>
<option value="Swaziland">Swaziland</option>
<option value="Sweden">Sweden</option>
<option value="Switzerland">Switzerland</option>
<option value="Syria">Syria</option>
<option value="Taiwan">Taiwan</option>
<option value="Tajikistan">Tajikistan</option>
<option value="Tanzania">Tanzania</option>
<option value="Thailand">Thailand</option>
<option value="Togo">Togo</option>
<option value="Tonga">Tonga</option>
<option value="Trinidad and Tobago">Trinidad and Tobago</option>
<option value="Tunisia">Tunisia</option>
<option value="Turkey">Turkey</option>
<option value="Turkmenistan">Turkmenistan</option>
<option value="Tuvalu">Tuvalu</option>
<option value="Uganda">Uganda</option>
<option value="Ukraine">Ukraine</option>
<option value="United Arab Emirates">United Arab Emirates</option>
<option value="United Kingdom">United Kingdom</option>
<option value="United States">United States</option>
<option value="Uruguay">Uruguay</option>
<option value="Uzbekistan">Uzbekistan</option>
<option value="Vanuatu">Vanuatu</option>
<option value="Vatican City">Vatican City</option>
<option value="Venezuela">Venezuela</option>
<option value="Vietnam">Vietnam</option>
<option value="Yemen">Yemen</option>
<option value="Zambia">Zambia</option>
<option value="Zimbabwe">Zimbabwe</option>
</select>
</section>
</div>

<div class="form-group">
        <label>ID / Passport Number</label> <input type="tel" name="ID" class="form-control" required>
        </div>

    <div class="form-group">

      
             <lable>  Enter Gender:</lable> <br>
             <input type="radio" name = "gender" value="Male"> Male <br>
             <input type="radio" name = "gender" value="Female"> Female <br>
        
</div>
<div class="form-group">
        <label>Years of Formal Education in English</label> <input type="text" name="formal" class="form-control" required>
        </div>

<div class="form-group">
<section >
<label >Highest Level of education</label><br/>
<span class="bfElementGroupNoWrap" id="bfElementGroupNoWrap68"  name="ff_nm_EducationLevel[]">
<input  class="ff_elem" type="radio" name="ff_nm_EducationLevel[]" value="primary" id="ff_elem68"/><label class="bfGroupLabel" id="bfGroupLabel68" for="ff_elem68">Primary</label>
<input  class="ff_elem" type="radio" name="ff_nm_EducationLevel[]" value="seconadry" id="ff_elem68_1"/><label class="bfGroupLabel" id="bfGroupLabel68_1" for="ff_elem68_1">Secondary</label>
<input  class="ff_elem" type="radio" name="ff_nm_EducationLevel[]" value="postgraduate" id="ff_elem68_2"/><label class="bfGroupLabel" id="bfGroupLabel68_2" for="ff_elem68_2">Postgraduate</label>
<input  class="ff_elem" type="radio" name="ff_nm_EducationLevel[]" value="others" id="ff_elem68_3"/><label class="bfGroupLabel" id="bfGroupLabel68_3" for="ff_elem68_3">Others</label>
</span>
</section>
<label >If others, please specify</label>
<textarea cols="20" rows="5" class="form-control" name="Specification" id="ff_elem69"></textarea>
</div>

<div class="form-group">
<section >
<label id="bfLabel79" for="ff_elem79">Upload passport size photo<span class="bfRequired">*</span> 
</label>
<input class="ff_elem" type="file" name="ff_nm_Passportphoto[]" id="ff_elem79"/>
<span id="ff_elem79_files"></span>
</section>
</div>

<div class="form-group">
        <label>Any Language Spoken Or Written</label> <input type="text" name="language" class="form-control" required>
        </div>

<div class="form-group">

      
<lable>  Do you have any Disability:</lable> <br>
<input type="radio" name = "disability" value="Yes"> Yes <br>
<input type="radio" name = "disability" value="No"> No <br>

</div>
<div class="form-group">
<label >If Yes, please explain the nature of your disability</label>
<textarea cols="20" rows="5" class="form-control" name="nature" id="ff_elem69"></textarea>
</div>

<div class="form-group">

<section >
<label >Religious Affiliation</label><br/>
<span name="ff_nm_Religious[]">
<input  class="ff_elem" type="radio" name="ff_nm_Religious[]" value="protestant" id="ff_elem110"/><label class="bfGroupLabel" id="bfGroupLabel110" for="ff_elem110">Protestant</label>
<input checked="checked"  class="ff_elem" type="radio" name="ff_nm_Religious[]" value="roman Catholic" id="ff_elem110_1"/><label class="bfGroupLabel" id="bfGroupLabel110_1" for="ff_elem110_1">Roman Catholic</label>
<input  class="ff_elem" type="radio" name="ff_nm_Religious[]" value="hindu" id="ff_elem110_2"/><label class="bfGroupLabel" id="bfGroupLabel110_2" for="ff_elem110_2">Hindu</label>
<input  class="ff_elem" type="radio" name="ff_nm_Religious[]" value="African Traditional Religion" id="ff_elem110_3"/><label class="bfGroupLabel" id="bfGroupLabel110_3" for="ff_elem110_3">African Traditional Religion</label>
<input  class="ff_elem" type="radio" name="ff_nm_Religious[]" value="muslim" id="ff_elem110_4"/><label class="bfGroupLabel" id="bfGroupLabel110_4" for="ff_elem110_4">Muslim</label>
<input  class="ff_elem" type="radio" name="ff_nm_Religious[]" value="ordained minister" id="ff_elem110_5"/><label class="bfGroupLabel" id="bfGroupLabel110_5" for="ff_elem110_5">Ordained Minister (For Divinity Applicants only)</label>
<input  class="ff_elem" type="radio" name="ff_nm_Religious[]" value="other" id="ff_elem110_6"/><label class="bfGroupLabel" id="bfGroupLabel110_6" for="ff_elem110_6">Other(Please specify)</label>
</span>
</section>
</div>

<div class="form-group">
<label >Specify Religious Affiliation</label>
<textarea cols="20" rows="5" class="form-control" name="affiliation" id="ff_elem69"></textarea>
</div>

<section >
<div class="form-group">
<label >Current Address</label><br/>

<section>
<label >Postal address</label>
<input type="text" name="ff_nm_Postaladdress[]" class="form-control" required>
</section>

<section >
<label >Postal Code</label>
<input type="text" name="ff_nm_Code[]" class="form-control" required>
</section>


<section >
<label >Town </label>
<input  type="text" name="ff_nm_Town[]" class="form-control" required>
</section>

<section>
<label >Country</label>
<input  type="text" name="ff_nm_Countryofresidence[]" class="form-control" required>
</section>

<section >
<label >Telephone (home)</span> 
</label>
<input type="tel" name="ff_nm_Telephone[]" class="form-control" required>
</section>

<section >
<label>Mobile no</label>
<input  type="tel" name="ff_nm_Mobileno[]" class="form-control" required>
</section>

<section >
<label>Your Email</label> <input type="email" name="YourEmail" class="form-control" required>
</section>

</div>
</section >

        <div class="form-group">
        <label>Your Inquiry</label>
        <textarea name="YourInquiry" class="form-control" Placeholder="Enter your inquiry here..." required></textarea>
        </div>
        
        <div class="form-group">
        <button type="submit" class="email-form_submit">Send</button>
        </div>

        <button type="button" class="bfNextButton button" type="submit" onclick="location.href = 'nextpage.php'(this, 'click');populateSummarizers();if(typeof bfRefreshAll != 'undefined'){bfRefreshAll();}" value="Next"><span>Next</span></button>
</div><!-- bfPage end -->
<div id="bfPage2" class="bfPage" style="display:none;">
<span class="bfErrorMessage" style="display:none"></span>
 

    </form>
    </div>

    <script >
    $(document).ready(function(){


        $('#contactform').validate({
            
            submitHandler: function(form){
                var form = $('#contactform').serialize();
                var url = $('#contactform').attr('action');

                $('#overlay').show();
                
                //ajax
                $.ajax({

                    type:'post',
                    url:url,
                    data: form,

                    success: function(response){

                        Swal.fire({
                            position: 'center',
                            icon: 'success',
                            title: 'Email Sent Succesfully',
                            showConfirmButton: false,
                            timer: 2500
                            })

                        $('#contactform').trigger("reset"); 
                        $('#overlay').hide();
                
                    }

                })
            }
        });



    });

    </script>

</body>
</div>
</html>